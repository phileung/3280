Finished:
Part 1
Part 2

Compiler:
VS 2010 C++ Express

Environment:
Windows 7 32-bit