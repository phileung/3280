	CSCI3260 Assignment 1 Keyboard and Mouse Events  

Name: 
Student ID:

Demo procedure:
	Key "1": start seesaw motion;
	Key "2": swing the left swing;
	Key "3": swing the right swing;
	Key "4": clockwise rotatation of roundabout;
	Key "5": clockwise rotatation of roundabout;
	Key "0": cease object movement;
	Key "Esc": Exit

